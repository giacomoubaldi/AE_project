
#include "DAQServerInterface.hh"

////////////*******  DAQServerInterface
DAQServerInterface::~DAQServerInterface(){}

